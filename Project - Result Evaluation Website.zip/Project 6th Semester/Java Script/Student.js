function validate()
{
	var a=document.getElementById("Studentid").value;
	var b=document.getElementById("Rollno").value;
	if(a=="12345" && b=="abcd")
	{
		return true;
	}
	else
	{
		alert("Wrong Input");
	}
}
	