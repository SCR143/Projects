function validate()
{
	var a=document.getElementById("Password").value;
	var b=document.getElementById("ConfirmPassword").value;
	if(a!=b)
	{
		alert("Error");
		return false;
	}
}