function validate()
{
	var Teacherid=document.getElementById("Teacherid").value;
	var Password=document.getElementById("Password").value;
	if(Teacherid=="12345" && Password=="abcd")
	{
		return true;
	}
	else
	{
		alert("Wrong Input");
	}
}
		
	