<!DOCTYPE html>
<html>
<head>
<link href="../css/Teacher.css" rel="stylesheet">
<title>Teacher Sign-up</title>
</head>
<h1 id="a">TEACHER SIGN-UP</h1>
<center>
<form action = "../php/Teachersignup.php" method="POST">
<fieldset>
</br></br>
<label for="FName">FIRST NAME</label>
<input type="text" name="FName" id="FName" required>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<label for="SName">SECOND NAME</label>
<input type="text" name="SName" id="SName" required></br></br>
<label for="male">MALE</label>
<input type="checkbox" name="male" id="male" value="male" >
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<label for="female">FEMALE</label>
<input type="checkbox" name="female" id="female" value="female" ></br></br>
<label for="Teacherid">TEACHER ID</label>
<input type="text" name="Teacherid" id="Teacherid" required></br></br>
<label for="branch">BRANCH</label>
</br>
<select name="branch" id="branch" >
<option value="ot">Others</option>
<option value="cse">Computer Science Engineering</option>
<option value="mech">Mechanical Engineering</option>
<option value="civil">Civil Engineering</option>
<option value="chem">Chemical Engineering</option>
<option value="ele">Electrical Engineering</option>
</select>
</br></br>
<label for="Emailid">Email-ID</label>
<input type="text" name="Emailid" id="Emailid" required></br></br>
<label for="Password">PASSWORD</label>
<input type="password" name="Password" id="Password" required>
</br></br>
<label for="ConfirmPassword">CONFIRM PASSWORD</label>
<input type="password" name="ConfirmPassword" id="ConfirmPassword" required>
</br></br></br></br>
<input type="submit" value="SUBMIT" name ="submit" onclick="validate()">
</br></br>
</fieldset>
</form>
</center>
<a href="../html/Teacher.html"><img src="../images/back.png" id="BACK" alt="BACK" /></a>
</html>

<?php
error_reporting(0);

$FName=$_POST['FName'];
$SName=$_POST['SName'];
$male=$_POST['male'];
$female=$_POST['female'];
$Teacherid=$_POST['Teacherid'];
$branch=$_POST['branch'];
$Emailid=$_POST['Emailid'];
$Password=$_POST['Password'];
$ConfirmPassword=$_POST['ConfirmPassword'];

$host="localhost";
$dbUsername="root";
$dbPassword="";
$dbname="minor project";
$connection = mysqli_connect($host,$dbUsername,$dbPassword,$dbname);


$sql = "INSERT INTO teachersignup VALUES('$FName', '$SName', '$male', '$female', '$Teacherid', '$branch', '$Emailid', '$Password', '$ConfirmPassword')";
$result = $connection-> query($sql);

$connection-> close();
?>