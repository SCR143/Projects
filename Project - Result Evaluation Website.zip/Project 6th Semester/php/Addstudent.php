<!DOCTYPE html>
<html>
<head>
<link href="../css/Addstudent.css" rel="stylesheet">
<title>Add Student</title>
</head>
<h1 id="a">ADD STUDENT</h1>
<center>
<form action="../php/Addstudent.php" method="post">
<fieldset>
</br></br>
<label for="FName">FIRST NAME</label>
<input type="text" name="FName" id="FName" required>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<label for="SName">SECOND NAME</label>
<input type="text" name="SName" id="SName" required></br></br>
<label for="male">MALE</label>
<input type="checkbox" name="male" id="male" value="male" >
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<label for="female">FEMALE</label>
<input type="checkbox" name="female" id="female" value="female" ></br></br>
<label for="srn">STUDENT ROLL NUMBER</label>
<input type="text" name="srn" id="srn" required></br></br>
<label for="sid">STUDENT ID</label>
<input type="text" name="sid" id="sid" required></br></br>
<label for="branch">BRANCH</label>
</br>
<select name="branch" id="branch" >
<option value="ot">Others</option>
<option value="cse">Computer Science Engineering</option>
<option value="mech">Mechanical Engineering</option>
<option value="civil">Civil Engineering</option>
<option value="chem">Chemical Engineering</option>
<option value="ele">Electrical Engineering</option>
</select>
</br></br>
<label for="Emailid">Email-ID</label>
<input type="text" name="Emailid" id="Emailid" required></br></br>
<label for="Mnumber">MOBILE NUMBER</label>
<input type="text" name="Mnumber" id="Mnumber" required></br></br>
</br></br></br></br>
<input type="submit" value="SUBMIT">
</br></br>
</fieldset>
</form>
</center>
<a href="../html/Teacherhome.html"><img src="../images/home.png" id="HOME" alt="HOME" /></a>
</html>

<?php
error_reporting(0);

$FName=$_POST['FName'];
$SName=$_POST['SName'];
$male=$_POST['male'];
$female=$_POST['female'];
$srn=$_POST['srn'];
$Studentid=$_POST['sid'];
$branch=$_POST['branch'];
$Emailid=$_POST['Emailid'];
$mobile=$_POST['Mnumber'];

$host="localhost";
$dbUsername="root";
$dbPassword="";
$dbname="minor project";
$connection = mysqli_connect($host,$dbUsername,$dbPassword,$dbname);


$sql = "INSERT INTO addstudent VALUES('$FName', '$SName', '$male', '$female', '$srn','$Studentid', '$branch', '$Emailid', '$mobile')";
$result = $connection-> query($sql);
$connection-> close();
?>