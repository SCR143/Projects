<!DOCTYPE html>
<html>
<head>
<link href="../css/Marks.css" rel="stylesheet">
<title>Marks</title>
</head>
<h1 id="a">MARKS</h1>
<center>
<form action="../php/Marks.php" method="post">
<fieldset>
</br></br>
<label for="s1">SUBJECT 1&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
<input type="text" name="s1" id="s1" required>
</br></br>
<label for="s2">SUBJECT 2&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
<input type="text" name="s2" id="s2" required>
</br></br>
<label for="s3">SUBJECT 3&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
<input type="text" name="s3" id="s3" required>
</br></br>
<label for="s4">SUBJECT 4&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
<input type="text" name="s4" id="s4" required>
</br></br>
<label for="s5">SUBJECT 5&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
<input type="text" name="s5" id="s5" required>
</br></br></br></br>
<input type="submit" value="SUBMIT">
</br></br>
</fieldset>
</form>
</center>
<a href="../html/Editmarks.html"><img src="../images/back.png" id="BACK" alt="BACK" /></a>
</html>

<?php
error_reporting(0);

$s1=$_POST['s1'];
$s2=$_POST['s2'];
$s3=$_POST['s3'];
$s4=$_POST['s4'];
$s5=$_POST['s5'];

$host="localhost";
$dbUsername="root";
$dbPassword="";
$dbname="minor project";
$connection = mysqli_connect($host,$dbUsername,$dbPassword,$dbname);


$sql = "INSERT INTO marks VALUES('$s1', '$s2', '$s3', '$s4', '$s5')";
$result = $connection-> query($sql);
$connection-> close();
?>